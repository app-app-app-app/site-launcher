<?php
// MANUAL
$site_name = "$source";
$site_url = "https://nakitlikfiyatai.com";
$app_price = 8000;
$rating_value = 4.9;
$rating_count = 476;
$app_currency = "TRY";
$site_lang = "tr-TR";
$adress_name = "Büyükdere Caddesi 199, 34394 Şişli, İstanbul, Türkiye";
$site_gmail = "support.nakitlikfiyatai@gmail.com";
$footer_contact_address = "Adres: $adress_name";
$footer_contact_email = "E-posta: $site_gmail";
$feedback_strong_1 = "Mert, 34 yaşında, İstanbul";
$feedback_strong_2 = "Aylin, 41 yaşında, Ankara";
$feedback_strong_3 = "Bora, 37 yaşında, İzmir";
$feedback_strong_4 = "Selin, 46 yaşında, Bursa";
$page_title_main = "$source | Yapay Zeka Trading Platformu, Piyasa Analizi ve Sinyaller";
$page_description_main = "$source ⭐ — Akıllı AI trading platformu; gerçek zamanlı piyasa analizi ve al-sat sinyalleri. Algoritmik veri takibiyle daha hızlı kararlar ⚡ Keşfedin.";


// Über-uns-Seite
$page_title_about = "Hakkımızda | $source – Misyon ve Ekip";
$page_description_about = "$source’yi harekete geçirenleri keşfedin: değerlerimiz, hedeflerimiz ve platformun arkasındaki uzman ekip. Güvenlik, şeffaflık, kullanıcı odaklılık ve yeniliği nasıl birleştirdiğimizi görün.";

// Bedingungen-Seite
$page_title_conditions = "Kullanım Şartları | $source – Kurallar ve Politikalar";
$page_description_conditions = "$source’nin kullanım şartlarını okuyun. Bu belge kullanıcı yükümlülüklerini ve platform politikalarını tanımlar; tam şeffaflık ve hukuki açıklık sağlar.";

// Kontakt-Seite
$page_title_contact = "İletişim | $source – Destek ve Yardım";
$page_description_contact = "Kayıt, hesabınız veya işlemlerle ilgili sorular mı var? $source ile iletişime geçin — destek ekibimiz hızlı, profesyonel ve güvenilirdir.";

// FAQ-Seite
$page_title_faq = "Sıkça Sorulan Sorular | $source – Cevaplar ve Bilgiler";
$page_description_faq = "Para yatırma, çekme, güvenlik ve $source’de işlem yapmaya ilişkin temel sorulara net ve anlaşılır cevaplar bulun. Daha fazla soru için destek ekibimiz her zaman hizmetinizde.";

// Datenschutz-Seite
$page_title_private = "Gizlilik Politikası | Kişisel Verilerinizin Korunması";
$page_description_private = "Kişisel verilerinizi nasıl topladığımızı, işlediğimizi ve koruduğumuzu öğrenin. Gizlilik politikamız şeffaflık, güvenlik ve bilgilerle sorumlulukla davranmayı garanti eder.";

// Registrierungs-Seite
$page_title_register = "$source | Platforma Erişim | Hızlı Kayıt";
$page_description_register = "$source’ye hızlı ve zahmetsizce kaydolun; birkaç dakika içinde tüm özelliklere tam erişim elde edin. Bilgilerinizi girin ve hemen başlayın.";

// ---------------------------------------------------------------------------------------------------

// HEADER FÜR ALLE SEITEN
$text_why_invest = "Neden yatırım yapmalı?";
$text_how_to_invest = "Nasıl yatırım yapılır?";
$text_who_we_are = "Hakkımızda";
$text_investment_risks = "Yatırım riskleri";
$text_benefits = "Avantajlar";
$text_faq = "SSS";
$text_log_in = "Giriş Yap";
$text_sign_up = "Kaydol";

// ---------------------------------------------------------------------------------------------------

// FOOTER FÜR ALLE SEITEN

$footer_logo_name = $source;
$footer_link_why_invest = "Neden yatırım yapmalı?";
$footer_link_how_to_invest = "Nasıl yatırım yapılır?";
$footer_link_investment_risks = "Yatırım riskleri";
$footer_link_benefits = "Avantajlar";
$footer_link_faq = "SSS";
$footer_link_who_we_are = "Hakkımızda";
$footer_link_contact = "İletişim";
$footer_link_privacy_policy = "Gizlilik";
$footer_link_terms_conditions = "Kullanım Şartları";
$footer_link_registration = "Kayıt";

$footer_contact_title = "İletişim bilgileri";
$footer_contact_address = "Adres: $adress_name";
$footer_contact_email = "E-posta: $site_gmail";

$footer_description = "$source güvenilir ve güvenli bir çevrimiçi işlem platformu sunar; finansal süreçleri şeffaf, izlenebilir ve verimli hale getirir. Yeni başlayanlar veya deneyimli yatırımcılar için modern araçlar, kişisel destek ve sezgisel bir arayüz bir arada. Dünyanın dört bir yanındaki binlerce kullanıcı, şeffaflık, yüksek güvenlik standartları ve müşteri odaklı yaklaşımı nedeniyle $source’e güveniyor. Verilerinizin ve sermayenizin korunması her zaman önceliğimizdir ve gelişmiş güvenlik teknolojileriyle desteklenir. $source topluluğunun bir parçası olun ve güvenle yatırım yapın.";
$footer_copyright = "© $source 2026";

// ---------------------------------------------------------------------------------------------------

// FORMULARE (ALLE BEREICHE)
$placeholder_fname = "Ad";
$placeholder_lname = "Soyad";
$placeholder_email = "E-posta adresi";
$button_sign_up = "Kaydol";

// ---------------------------------------------------------------------------------------------------

// HERO-BEREICH
$heading_main = "$source – Hisse senetleri ve kripto paralar için yapay zekâ tabanlı otomatik yatırım platformu";
$text_intro = "Yatırım yolculuğunuza $source ile başlayın — yapay zekâ kullanan, hisse ve kripto piyasalarına otomatik yatırım yapan akıllı bir platform. $currency’den itibaren deneyim gerektirmeden başlayın; gerçek zamanlı analizlerle en iyi sonuçlar hedeflenir.";

// Warum investieren? BEREICH
$heading_reasons = "$source ile yatırım yapmanın nedenleri";
$text_protect_capital = "Sermayenizi enflasyona karşı koruyun ve geleceğe dönük bir strateji izleyin";
$text_inflation = "Enflasyon satın alma gücünü yavaşça düşürür. Birikimleri hareketsiz bırakmak yerine akıllı yatırım yaklaşımları uzun vadeli büyüme sağlar. Otomatik sistemler istikrarı artırır ve sağlam bir finansal temel oluşturur.";
$heading_auto_investing = "Otomatik Yatırım – Borsa Bilgisi Olmadan da";
$text_auto_investing = "$source gelişmiş yapay zekâ ile yatırımlarınızı yönetir. Grafiklerle veya piyasa takibiyle zaman harcamanıza gerek yok — sistem fırsatları gerçek zamanlı tespit eder ve sermayeyi stratejik olarak kullanır. Etkili yatırım yapın ve zamandan tasarruf edin.";
$heading_min_invest = "$currency ile yatırım yapmak – basit ve erişilebilir";
$text_min_invest = "$source’in güçlü yapay zekâ teknolojisinden $currency ile $currency seviyesinden başlayan başlangıç tutarıyla yararlanın. Yüksek engeller olmadan başlamak isteyenler için ideal.";
$heading_control = "Tam kontrol ve şeffaf görünüm";
$text_control = "$source ile sermayeniz üzerinde daima tam kontrole sahip olursunuz. Kazançlar istediğiniz gibi yeniden yatırılabilir veya çekilebilir. Platform adil, şeffaf ve gizli ücretler içermez.";
$button_signup = "Şimdi kaydolun";

// CALCULATOR BEREICH
$text_expected_returns = "$source ile makul getiriler ne kadar olabilir?";
$text_my_investment = "YATIRIMIM:";
$text_usage_period = "SÜRE:";
$text_days = "Gün";

// Wie KI-Investments funktionieren
$text_h2_ai_investments = "$source ile yapay zekâ destekli yatırımlar nasıl çalışır";
$text_h3_registration = "Hızlı kayıt – $source ile anında başlangıç";
$text_p_registration = "Kayıttan sonra size kişisel bir iletişim kişisi tarafından destek sağlanır. Hesap genellikle birkaç dakika içinde kullanıma hazır olur.";
$text_h3_trading_approach = "Tutarlı sonuçlar için strateji geliştirme";
$text_p_trading_approach = "$source ile hedeflerinize ve risk seviyenize göre uyarlanmış bir işlem stratejisinden yararlanırsınız — istikrarlı ve sürdürülebilir büyüme için.";
$text_h3_ai_trading = "Otomatik piyasa izleme ve yapay zekâ kararları";
$text_p_ai_trading = "$source, en gelişmiş yapay zekâ ile piyasaları gerçek zamanlı analiz eder, fırsatları tespit eder ve işlemleri otonom olarak gerçekleştirir — hassas, verimli ve insan müdahalesi gerektirmeden.";
$text_h3_profit_flexibility = "Esnek kar yönetimi";
$text_p_profit_flexibility = "Kazançları istediğiniz zaman çekmeye ya da yeniden yatırıma karar verebilirsiniz. Sermayeniz her zaman erişilebilir durumda kalır.";

// RISIKOMANAGEMENT
$text_h2_risk_control = "Risk yönetimi ve $source ile koruma";
$text_h3_ai_analysis = "Kendi kendini geliştiren yapay zekâ ile akıllı piyasa analizleri";
$text_p_ai_analysis = "$source, fiyatlar, hacimler, haberler, sosyal medya duyarlılığı, makroekonomik göstergeler ve teknik örüntüler gibi büyük veri setlerini gerçek zamanlı değerlendiren ileri düzey, kendi kendini öğrenen algoritmalar kullanır. Yapay zekâ gizli fırsatları keşfeder, olasılıkları değerlendirir ve otomatik olarak riskli piyasa dönemlerini filtreleyerek duygu kaynaklı hatalardan arınmış, hassas işlem sinyalleri üretir. Sistem yeni koşullara sürekli uyum sağlar ve zaman içinde getiriyi riskle dengeler, böylece sağlam ve sürdürülebilir bir strateji oluşturur.";
$text_h3_custom_risk = "Kişisel risk profiliniz – bireysel olarak optimize edilir";
$text_p_custom_risk = "Her yatırımcı farklıdır: bazıları yüksek büyüme ister, bazıları güvenliğe öncelik verir. $source, savunmacıdan büyüme odaklıya kadar risk profilinizi hassas şekilde ayarlamanıza izin verir. Seçim sonrası yapay zekâ pozisyon büyüklüğü, stop-loss, take-profit ve giriş/çıkış sıklığı gibi parametreleri sürekli optimize eder. Strateji her zaman hedeflerinize ve kişisel konfor seviyenize otomatik olarak uyum sağlar.";
$text_h3_transparency = "Sermayeniz üzerinde maksimum şeffaflık ve kontrol";
$text_p_transparency = "$source’de tam şeffaflık hakimdir. Her işlem — alım, satım, değişiklikler, ücretler — ayrıntılı olarak ve gerçek zamanlı kaydedilir. Gizli maliyet yok, sürpriz yok. Panonuz bakiye, geçmiş, kar/zarar eğrileri, istatistikler ve risk pozisyonlarını açık şekilde gösterir. Kontrol sizdedir: Platform sizin için çalışır, tam tersi değil.";

// VORTEILE
$text_h2_benefits = "$source ile avantajlarınız – sistematik ve sürdürülebilir yatırım";
$text_h3_ai_investing = "Güncel yapay zekâ ile yatırım yapın — hassas ve zahmetsiz";
$text_p_ai_investing = "Grafikleri veya haberleri saatlerce incelemenize gerek yok. $source’in yapay zekâsı sürekli çalışır: binlerce piyasayı analiz eder, milisaniyeler içinde örüntüleri tanır, hareketleri yüksek doğrulukla tahmin eder ve işlemleri doğru zamanda gerçekleştirir. Teknik bilgi gerektirmeyen profesyonel algoritmik işlem.";
$text_h3_easy_investing = "Basit yatırım — güvenli ve herkes için uygun";
$text_p_easy_investing = "$source her seviyeden kullanıcının başlayabileceği şekilde tasarlanmıştır — deneyim veya büyük sermaye gerektirmez. Arayüz sezgisel: net adımlar, basit ayarlar ve anlaşılır içerikler. Yeni başlayanlar bile ilk otomatik stratejilerini 10–15 dakikada aktif edebilir. Videolar, rehberler ve duyarlı destek hizmeti sunulur.";
$text_h3_support = "Başarı için kişisel destek";
$text_p_support = "İlk yatırmanızdan sonra size bir kişisel danışman atanır — risk profilinizi belirlemenize yardımcı olacak, özellikleri açıklayacak, başlangıç parametreleri önerecek ve kullanım süresince sizinle iletişimde kalacak bir uzman.";
$text_h3_opportunities = "Sınırsız fırsatlar – gelir sermayenizle büyür";
$text_p_opportunities = "$source ile sermayeniz sürekli çalışır; seyahat ederken veya uyurken bile. Otomatik optimizasyon ve karların yeniden yatırımı potansiyel olarak üstel büyüme sağlayabilir. Ekran stresi yok, duygular yok: Sonuçları arada kontrol edin ve kazançları çekin. Böylece uzun vadeli pasif gelir kaynağı inşa edersiniz.";

// FEEDBACK
$feedback_h2_title = "Kullanıcı deneyimleri";

$feedback_h3_1 = "$currency ile ek gelir elde etmek";
$feedback_p_1 = "Benim hiçbir deneyimim yoktu ama her şey otomatik ilerledi. Kısa sürede ilk sonuçları gördüm ve artık düzenli ek gelir elde ediyorum. — Kadın";

$feedback_h3_2 = "Yeni başlayanlar için mükemmel – basit ve etkili";
$feedback_p_2 = "$source ile başlamak beklenmedik şekilde kolaydı. Kişisel destek sayesinde stresten uzak, düzenli ve sağlam sonuçlar elde ediyorum. — Kadın";

$feedback_h3_3 = "Sermayem nihayet benim için çalışıyor";
$feedback_p_3 = "Birikimleri boşta tutmak yerine artık akıllıca yatırım yapıyorum. $source zahmetsizce istikrarlı sonuçlar sunuyor. — Erkek";

$feedback_h3_4 = "Mali özgürlük – dünyanın her yerinde";
$feedback_p_4 = "Seyahat etmek ve gelir elde etmeye devam etmek istiyordum. $source ile bunu yapabiliyorum: getirilere her zaman erişimim var. — Kadın";

// PARTNER
$partners_h2_title = "Ortaklar ve iş birlikleri";

// FAQ & KONTAKT
$faq_h2_title = "Sıkça Sorulan Sorular – net ve anlaşılır yanıtlar";
$contact_h2_title = "Bize ulaşın";

$lang['faq_q1'] = '%s ile başlamak için ne kadar sermaye gerekiyor?';
$lang['faq_a1'] = '%s ile %s tutarından itibaren başlayabilirsiniz. Birçok kullanıcı platformu tanımak için küçük başlayıp hedeflere ve risk toleransına göre yatırımlarını kademeli olarak artırır.';

$lang['faq_q2'] = '%s’de para çekme ne kadar sürer?';
$lang['faq_a2'] = 'Çekim talepleri genellikle 24 saat içinde işlenir. Ödeme yöntemi ve bankaya bağlı olarak para yatması 1–3 iş günü sürebilir.';

$lang['faq_q3'] = '%s yatırımlarımı nasıl korur?';
$lang['faq_a3'] = 'Modern bir platform olarak %s şifreli veri aktarımı, doğrulanmış hesaplar ve sürekli risk yönetimi gibi çok katmanlı güvenlik önlemleri uygular. Profilinizde ekstra güvenlik seçeneklerini etkinleştirerek korumayı artırabilirsiniz.';

$lang['faq_q4'] = '%s’yi kullanmak için deneyim gerekiyor mu?';
$lang['faq_a4'] = 'Hiçbir deneyim gerekmez! %s, yeni başlayanların hızla adapte olacağı şekilde tasarlanmıştır. Arayüz sizi adım adım yönlendirir; daha fazla kontrol istediğinizde ayarları her zaman değiştirebilirsiniz.';














// ---------------------------------------------------------------------------------------------------

// ÜBER-UNS-SEITE
$about_heading = "Hakkımızda";
$about_text_1 = "$source, mutlak acemiden profesyonel trader’a kadar her yatırımcıya hisse ve kripto para otomatik yatırımları için güvenli, modern ve tamamen şeffaf bir ortam sağlama amacıyla geliştirildi. Sürdürülebilir başarı; açıklık, dürüstlük ve karşılıklı güven temelli olur. Bu nedenle platformdaki her etkileşim — ilk kayıttan kazançların çekilmesine kadar — bu ilkelere uyar. Her süreç, her işlem ve her yatırım kararı objektif verilere dayanır; gizli mekanizmalar veya belirsiz uygulamalar yoktur.";

$about_text_2 = "Ekibimiz, yapay zekâ ve algoritmik işlem sistemleri geliştiricileri, geniş piyasa deneyimine sahip finans analistleri, siber güvenlik uzmanları ve uyumluluk profesyonellerinden oluşan nitelikli uzmanları bir araya getirir. Sadece bir ürün geliştirmiyoruz — her platform bileşenini sürekli izliyor, test ediyor ve optimize ediyoruz. Gerçek zamanlı piyasa verilerinin kalitesinden sunucu altyapısının istikrarına ve işlem sinyallerinin doğruluğuna kadar tüm öğeler çok katmanlı kalite kontrollerine ve bağımsız denetimlere tabidir. Amacımız sizin için güvenilir, tekrarlanabilir ve somut yenilikler sunmaktır.";

$about_image = "team.png"; // НЕ ТРОГАТЬ!!!
$about_image_alt = "Ekip";

$about_text_3 = "Kişisel verilerinizin ve sermayenizin korunması bizim için önceliktir. $source uluslararası kabul görmüş güvenlik standartlarına uygun çalışır: KVKK uyumu ve PCI-DSS gibi protokoller ile gelişmiş şifreleme (TLS 1.3+, AES-256). Fonlar düzenlenmiş finans kurumlarında ayrı hesaplarda tutulur. Bağımsız penetrasyon testleri ve kapsamlı güvenlik denetimleri, bilgilerin ve varlıkların büyük bankalarla ve küresel yatırım sistemleriyle karşılaştırılabilir seviyede korunmasını sağlar.";

$about_text_4 = "Teknoloji önemli olmakla birlikte bir yatırımcının başarısının yalnızca algoritmalara bağlı olmadığını biliyoruz. Bu yüzden güçlü otomasyonu birinci sınıf kişisel hizmetle birleştiriyoruz. Her kayıtlı kullanıcıya bir kişisel danışman atanır — stratejiyi hedeflerinize göre uyarlayan, özellikleri açıklayan, soruları yanıtlayan ve kullanım boyunca size destek veren bir profesyonel. Anonim chatbot değil: finansal ilerlemeniz için çalışan gerçek insanlarla konuşun.";

$about_text_5 = "Yenilik bizim için bir slogan değil, günlük bir taahhüttür. Ekibimiz yeni piyasa desenlerini analiz eder, makine öğrenimi modellerini iyileştirir, yeni veri kaynaklarını entegre eder ve işlemleri daha verimli kılan özellikler geliştirir. Her güncelleme, geçmiş verilerle ve kontrollü canlı ortamlarda test edildikten sonra tüm kullanıcılara sunulur. Mucizeler veya garantiler vaat etmiyoruz: Hız, doğruluk ve uyum kabiliyeti gerektiren bir piyasada size rekabet avantajı sağlamayı amaçlayan araçlar sunuyoruz.";

$about_text_6 = "Binlerce kullanıcı için $source otomatik yatırıma ciddi bir adım atmanın ilk adresi oldu. Birçoğu mütevazı sermaye ve muhafazakâr risk profilleriyle başladı ve istikrarlı sonuçlar, yüksek şeffaflık ve kişisel destek sayesinde olanaklarını kademeli olarak genişletti. Yeni finansal perspektifler sunmaktan gurur duyuyoruz — sadece profesyoneller değil, yatırım yapmayı karmaşık, zaman alıcı veya erişilemez bulanlar da güvenle başlayabilir. Doğrulanmış teknoloji ve adanmış bir ekip sizin için çalışır.";

$about_text_7 = "Kısacası: $source bir işlem platformundan çok daha fazlasıdır. Tam şeffaflık, en yüksek profesyonellik ve sağlam güvene dayalı entegre bir ekosistemdir. En son yapay zekâ teknolojilerini insan uzmanlığı, sıkı risk yönetimi ve kişisel destek ile bir araya getiriyoruz. Amacımız, kalıcı ve istikrarlı bir servet inşa etme yolunda güvenilir ortağınız olmaktır. $source ile körü körüne yatırım yapmazsınız: Yapısal, güvenlik odaklı ve kararlarınız üzerinde tam kontrol sahibi bir şekilde yatırım yaparsınız.";

// ---------------------------------------------------------------------------------------------------

// AGB
$terms_heading = "Kullanım Şartları";

$terms_text_1 = "Bu belge $source platformunun kullanımına ilişkin genel koşulları (\"Koşullar\") belirler. Kullanım ve platform işletmecisi ile siz kullanıcı arasındaki hak ve yükümlülükleri düzenler. Platformu kullanmadan, hesap açmadan veya işlem yapmadan önce lütfen bu koşulları dikkatlice ve eksiksiz okuyun. Bunlar kullanımın hukuki temelini oluşturur ve her iki taraf için bağlayıcıdır.";

$terms_text_2 = "Kayıt, giriş, sunulan özelliklerin kullanımı veya $source üzerindeki diğer aktivitelerin yürütülmesiyle bu Kullanım Şartlarını açıkça ve tamamen kabul etmiş sayılırsınız. $source yalnızca 18 yaşından büyük kişiler için kullanıma açıktır. Reşit olmayan veya hukuken işlem yapma ehliyeti olmayan kişilerin platformu kullanmasına izin verilmez. Bu yaş şartının ihlali şüphesinde hesapların askıya alınması, kısıtlanması veya silinmesi hakkını saklı tutarız.";

$terms_text_3 = "Platformun işletimi, teknik kesintilere, bakım zamanlarına, güncellemelere veya arızalara tabi olabilir — ör. piyasa dalgalanmaları, yüksek sunucu yoğunluğu veya dış etkenler nedeniyle. Yüksek erişilebilirlik hedeflesek de sürekli bir çalışma garantisi veremeyiz. Fonksiyonlar, algoritmalar, fiyat modelleri veya mevcut piyasalar her zaman genişletilebilir, değiştirilebilir, kısıtlanabilir veya sonlandırılabilir; bunlardan dolayı $source’e karşı hak talep edilemez.";

$terms_text_4 = "Platformdaki tüm içerikler — metinler, grafikler, tasarım, yazılım, algoritmalar, ticari markalar, logolar ve yapay zekâ analizleri — telif, marka ve diğer haklarla korunur ve $source veya lisans verenlerine aittir. Yazılı iznimiz olmadan çoğaltma, dağıtım, kamuya sunma veya ticari kullanım yasaktır ve cezai ve hukuki sonuçlar doğurabilir.";

$terms_text_5 = "Kullanıcı olarak verdiğiniz tüm bilgilerin (ör. kimlik bilgileri, iletişim, ödeme bilgileri) doğru, eksiksiz ve güncel olmasından sorumlusunuz. Yanlış veya yanıltıcı bilgiler hesap askıya alınmasına, çekimlerin bekletilmesine veya hukuki süreçlere yol açabilir. Kişisel verileriniz yalnızca Gizlilik Politikamız ve KVKK’ya uygun olarak işlenir. Yüksek güvenlik ve şeffaflık standartları uygularız.";

$terms_text_6 = "$source üzerinden aldığınız tüm yatırım ve işlem kararları — manuel ya da yapay zekâ otomasyonları aracılığıyla olsun — tamamen sizin sorumluluğunuzdadır ve risk size aittir. $source teknik altyapı sağlar ancak kişisel finansal danışmanlık, tavsiye veya kazanç garantisi vermez. Finans piyasaları (hisse ve kripto dahil) son derece dalgalı olabilir ve yatırılan sermayenin tamamının kaybedilmesine yol açabilir. Geçmiş performans gelecekteki sonuçların garantisi değildir. Sadece kaybetmeyi göze alabileceğiniz tutarlarla yatırım yapın.";

$terms_text_7 = "Bu koşulları düzenleyici değişiklikler, teknik gelişmeler veya yeni pazar gereksinimleri gibi sebeplerle istediğimiz zaman güncelleme veya ekleme hakkını saklı tutarız. Önemli değişiklikler genellikle en az 14 gün önceden e-posta, platform bildirimleri veya web sitesi yoluyla bildirilir. Platformu değişikliklerin yürürlüğe girmesinden sonra kullanmaya devam etmeniz onayıznız olarak kabul edilir. Önemli değişikliklerde hesabınızı kapatma hakkına sahipsiniz.";

$terms_text_8 = "Güvenlik ve şeffaflık eylemlerimizin temel prensipleridir. Modern şifreleme teknolojileri kullanır, düzenli güvenlik denetimleri yapar, müşteri fonlarını ayrı hesaplarda tutar ve KYC/AML gibi sıkı uyumluluk süreçleri uygularız. Tüm işlemler ve süreçler açık ve izlenebilir şekilde belgelenir. Adil, dürüst ve müşteri odaklı çalışmayı taahhüt ederiz: Güveniniz en değerli varlığımızdır.";

// ---------------------------------------------------------------------------------------------------

// KONTAKTSEITE
$contact_heading = "İletişim";

$contact_intro = "Uzman destek ekibimiz $source ile ilgili sorularınız ve talepleriniz için güvenilir ve yetkin destek sağlar. Bilgi almak, kayıtlı olmak veya platformu kullanmak fark etmeksizin, size kişisel olarak yardımcı oluyoruz ve her zaman iyi desteklendiğinizi hissetmenizi sağlıyoruz.";

$contact_how_to = "Nasıl bize ulaşabilirsiniz";

$contact_how_to_text = "Hesabınız ve $source kullanımıyla ilgili tüm konularda hızlı ve doğru yardım sunuyoruz. Ekip, Pazartesi–Cuma iş saatleri içinde (TSİ) hizmet vermekte olup talepleri öncelikle işler. Sizi desteklediğimiz tipik alanlar:";

$contact_list_1 = "Hesap açma ve doğrulama ile tam hesap yönetimi (profil ve risk ayarları dahil)";
$contact_list_2 = "Platformun veya uygulamanın kullanımı sırasında teknik destek ve hata yardımı";
$contact_list_3 = "Para yatırma, çekme, işleme süreleri ve desteklenen ödeme yöntemleriyle ilgili sorular";
$contact_list_4 = "Özellikler, stratejiler, yapay zekâ algoritmaları ve mevcut ticaret araçları hakkında detaylı bilgiler";
$contact_list_5 = "Platformun geliştirilmesi için geri bildirim, fikir ve iyileştirme önerileri";
$contact_list_6 = "Genel sorulardan bireysel ihtiyaçlara kadar tüm diğer talepler için destek";

$contact_send_message = "Mesaj gönder";

$contact_send_message_text = "Aşağıdaki güvenli iletişim formunu kullanın. Talebinizi hızlı ve doğru işleyebilmemiz için ilgili tüm alanları doldurun. Genellikle iş günlerinde 24 saat içinde yanıt alırsınız — çoğu zaman daha hızlı. Acil teknik sorunlarda canlı sohbet (iş günleri 9–18 arası) mevcuttur.";

$contact_info = "İletişim bilgileri";

$contact_info_text = "Hedefimiz $source deneyiminizi mümkün olduğunca hoş, sorunsuz ve başarılı kılmaktır. Bu yüzden açık iletişim, şeffaflık ve çözüm odaklı destek önemsiyoruz. Bize form, e-posta veya belirli durumlarda telefon aracılığıyla ulaşabilirsiniz. Memnuniyetiniz ve güvenliğiniz önceliğimizdir.";

// ---------------------------------------------------------------------------------------------------

// FAQ-SEITE
$faq_page_heading = "Sıkça Sorulan Sorular – SSS";
$faq_page_subheading = "Sorularınız mı var? Yanıtları burada bulun.";
$faq_page_intro_1 = "Bu bölümde hesaplar, ödemeler, güvenlik ve platform kullanımıyla ilgili temel konulara kısa ve net cevaplar bulacaksınız.";
$faq_page_intro_2 = "Amacımız sizi adım adım yönlendirmek ve baştan itibaren şüpheleri ortadan kaldırmaktır.";
$faq_page_intro_3 = "Belirli sorular için ekibimiz her zaman kişisel olarak yanınızdadır.";
$faq_page_section_heading = "SSS – Kullanıcıların sıkça sorduğu soruların cevapları";

// ---------------------------------------------------------------------------------------------------

// DATENSCHUTZ
$private_policy_heading = "Gizlilik Politikası";

$private_policy_intro = "Kişisel verilerinize sorumlu şekilde yaklaşmak $source için en yüksek öneme sahiptir. Bilgileri şeffaf olarak, belirlenmiş amaçlarla ve yürürlükteki yasalara — özellikle KVKK kapsamında — uygun şekilde işleriz. Bu politikada hangi verileri topladığımızı, neden kullandığımızı, ne kadar süre sakladığımızı ve nasıl koruduğumuzu açıklıyoruz.";

$private_policy_section_1_heading = "1. Veri sorumlusu";
$private_policy_section_1_text = "KVKK anlamında kişisel verilerinizden sorumlu olan taraf $source web sitesi ve platform işletmecisidir. İlgili iletişim bilgileri ve detaylar sayfanın yasal bilgiler bölümünde bulunur. Gizlilikle ilgili sorularınızda veri koruma sorumlumuzla iletişime geçebilirsiniz.";

$private_policy_section_2_heading = "2. Toplanan veriler";
$private_policy_section_2_text = "Hizmetlerimizi sunmak, yasal yükümlülükleri yerine getirmek ve platformun güvenli işletimini sağlamak için yalnızca gerekli verileri toplar ve işleriz. Bunlar özellikle şunlardır:";
$private_policy_section_2_list = [
    "Kimlik bilgileri: Ad ve soyad, doğum tarihi (yaş ve kimlik doğrulaması için).",
    "İletişim bilgileri: E-posta adresi, telefon numarası (isteğe bağlı), ikamet ülkeniz ve gerekirse adres.",
    "Hesap ve işlem bilgileri: Ödeme detayları, para yatırma ve çekme işlemleri, işlem geçmişi.",
    "Teknik ve kullanım verileri: IP adresi, tarayıcı türü, cihaz bilgileri, erişim zamanları, log kayıtları.",
    "Doğrulama belgeleri: Kimlik belgeleri, adres kanıtı veya KYC/AML incelemeleri için gerekli diğer belgeler (sadece yasal gereklilik halinde)."
];
$private_policy_section_2_note = "Özel nitelikli kişisel veriler (ör. sağlık verileri veya dini inançlar) genel olarak toplanmaz; yasal olarak açıkça gerekli olmadıkça veya açık rızanız alınmadıkça işlenmez.";

$private_policy_section_3_heading = "3. Toplama yöntemleri";
$private_policy_section_3_text = "Verileriniz çeşitli güvenli kanallar aracılığıyla toplanır:";
$private_policy_section_3_list = [
    "Doğrudan sizden: Örn. kayıt sırasında, profil bakımında, doğrulama belgeleri sunarken veya iletişim formunu kullanırken sağladığınız veriler.",
    "Otomatik olarak: Örn. çerezler, sunucu logları, analiz araçları ve platform kullanımına ilişkin cihaz verileri yoluyla toplanan bilgiler.",
    "Üçüncüler aracılığıyla: Örn. ödeme sağlayıcıları (para giriş/çıkışları için), kimlik doğrulama hizmetleri (KYC/AML) veya rızanızla sosyal giriş servisleri."
];

$private_policy_section_4_heading = "4. İşleme amaçları";
$private_policy_section_4_text = "Kişisel verilerinizi yalnızca açık ve meşru amaçlar için işleriz:";
$private_policy_section_4_list = [
    "Kullanıcı hesabınızın oluşturulması, yönetimi ve platform işlevlerinin sağlanması.",
    "Ödeme süreçlerinin yürütülmesi ve güvence altına alınması (para yatırma ve çekme işlemleri).",
    "Kişisel müşteri desteği ve taleplerinizin işlenmesi.",
    "Yasal ve düzenleyici yükümlülüklerin yerine getirilmesi (örn. KYC, AML ve vergi gereklilikleri).",
    "BT güvenliğinin sağlanması ve dolandırıcılık, kötüye kullanım ve saldırılara karşı korunma.",
    "Kullanıcı deneyiminin iyileştirilmesi ve platformun geliştirilmesi.",
    "Pazarlama ve bilgilendirme amaçları — yalnızca açık rıza temelinde."
];

$private_policy_section_5_heading = "5. İşlemenin hukuki dayanakları";
$private_policy_section_5_list = [
    "Bir sözleşmenin yerine getirilmesi veya sözleşme öncesi işlemler (KVKK madde benzeri hukuki dayanaklar).",
    "Yasal yükümlülüklerin yerine getirilmesi (örn. kara para aklama ile mücadele çerçevesinde).",
    "Meşru menfaatlerin korunması (örn. platformun istikrarı ve güvenliğinin sağlanması).",
    "Açık rızanız (örn. pazarlama veya isteğe bağlı ek özellikler için)."
];

$private_policy_section_6_heading = "6. Veri paylaşımı";
$private_policy_section_6_text = "Verileriniz yalnızca gerektiğinde ve özenle seçilmiş ortaklarla paylaşılır:";
$private_policy_section_6_list = [
    "Para transferlerini yürütmek için ödeme hizmeti sağlayıcıları ve bankalar.",
    "KYC/AML incelemelerini gerçekleştiren uzmanlaşmış hizmet sağlayıcılar.",
    "İlgili hizmet sözleşmeleri imzalanmış BT ve bulut sağlayıcıları.",
    "Analiz ve güvenlik araçları; mümkün olduğunda anonimleştirilmiş veya kısmen anonimleştirilmiş verilerle çalışır.",
    "Dış danışmanlar (örn. avukatlar, vergi danışmanları) yasal gereklilikler çerçevesinde.",
    "Yasal zorunluluk halinde yetkili makamlar veya mahkemelerle paylaşım."
];
$private_policy_section_6_note = "Kişisel verileriniz üçüncü taraflara ticari amaçla satılmaz veya aktarılmaz.";

$private_policy_section_7_heading = "7. Uluslararası veri aktarımı";
$private_policy_section_7_text = "Bazı durumlarda EAA dışındaki hizmet sağlayıcıları (ör. bulut veya analiz hizmetleri) kullanabiliriz. Bu gibi durumlarda uygun koruyucu önlemler (ör. standart sözleşme maddeleri, bağlayıcı şirket kuralları veya Avrupa Komisyonu uygunluk kararları) ile yeterli düzeyde veri koruması sağlanır.";

$private_policy_section_8_heading = "8. Veri güvenliği";
$private_policy_section_8_text = "Verilerinizi korumak için kapsamlı teknik ve idari tedbirler alıyoruz:";
$private_policy_section_8_list = [
    "Güncel protokollerle şifreli veri aktarımı (örn. TLS 1.3+).",
    "Huzur halinde hassas verilerin güçlü şifrelenmesi (örn. AES-256).",
    "Bağımsız uzmanlar tarafından düzenli güvenlik denetimleri, penetrasyon testleri ve incelemeler.",
    "Sistemlerin şüpheli faaliyetler ve saldırı girişimleri açısından sürekli izlenmesi.",
    "Ekip içinde sıkı erişim kısıtlamaları ve rol tabanlı izinler.",
    "Müşteri fonlarının düzenlenmiş partner kurumlarda ayrı hesaplarda tutulması."
];
$private_policy_section_8_note = "Her türlü riske karşı mutlak koruma teknik olarak garanti edilemez, ancak aldığımız önlemlerle riskleri çok düşük seviyeye indiriyoruz.";

$private_policy_section_9_heading = "9. Saklama süresi";
$private_policy_section_9_text = "Verilerinizi yalnızca belirtilen amaçlar için gerekli olduğu sürece veya yasal zorunluluklar gerektirdiği müddetçe saklarız:";
$private_policy_section_9_list = [
    "Hesabınızın aktif kullanım süresi ve sözleşmesel ilişki boyunca.",
    "Hesabın kapatılmasından sonra yasal saklama süreleri boyunca (örn. vergi ve düzenleyici amaçlar için genellikle 5–10 yıl).",
    "Rıza temelli işlemler (örn. pazarlama) için rızanın geri çekilmesine kadar."
];
$private_policy_section_9_note = "Veriler artık gerekli olmadığında güvenli şekilde silinir veya anonimleştirilir.";

$private_policy_section_10_heading = "10. İlgili kişinin hakları";
$private_policy_section_10_text = "Kişisel verilerinizle ilgili olarak geniş haklara sahipsiniz. Özellikle şunları yapabilirsiniz:";
$private_policy_section_10_list = [
    "Hangi verilerin sizle ilgili saklandığına dair bilgi talep edin.",
    "Yanlış veya eksik verilerin düzeltilmesini veya tamamlanmasını talep edin.",
    "Yasal saklama yükümlülükleri olmadığı sürece verilerinizin silinmesini isteyin.",
    "Bazı durumlarda işlem kısıtlaması talep edin.",
    "Verilerinizi yapılandırılmış, yaygın ve makine tarafından okunabilir formatta alın (veri taşınabilirliği).",
    "Geleceğe yönelik olarak verdiğiniz rızaları istediğiniz zaman geri çekin.",
    "İlgili veri koruma denetim kuruluşuna şikâyet başvurusunda bulunun."
];

$private_policy_section_11_heading = "11. Çerezler ve benzeri teknolojiler";
$private_policy_section_11_text = "Platformun işlevselliğini sağlamak, kullanım analizleri yapmak ve deneyimi optimize etmek için çerezler ve benzeri teknolojiler kullanıyoruz. Temel çerezler her zaman aktiftir; analitik ve pazarlama çerezleri önceden onayınıza bağlıdır. Daha fazla ayrıntı Çerez Politikamızda yer alır.";

$private_policy_section_12_heading = "12. Gizlilik politikasındaki değişiklikler";
$private_policy_section_12_text = "Yasal değişiklikler, düzenleyici gereklilikler veya yeni özellikler nedeniyle politikayı zaman zaman güncelleyebiliriz. Güncellenmiş versiyon her zaman web sitesinde bulunur. İlgili değişiklikler hakkında sizi e-posta veya platform üzerinden bilgilendiririz.";

$private_policy_section_13_heading = "13. Veri koruma ile ilgili iletişim";
$private_policy_section_13_text = "Gizlilik politikası, haklarınız veya veri işleme ile ilgili sorularınız için $site_gmail adresine e-posta ile veya sayfadaki iletişim formu üzerinden ulaşabilirsiniz. Veri koruma sorumlumuz talebinizi inceleyip zamanında yanıtlayacaktır.";

$private_policy_agreement = "$source’ü kullanarak bu gizlilik politikasını okuduğunuzu ve içeriğini kabul ettiğinizi onaylarsınız.";

$private_policy_thank_you = "Güveniniz için teşekkür ederiz. Verilerinizin ve gizliliğinizin korunması bizim için öncelikli olmaya devam edecektir.";

// ---------------------------------------------------------------------------------------------------

// REGISTRIERUNG
$register_heading = "Şimdi $source ile başlayın ve birkaç dakika içinde faaliyete geçin";
?>
